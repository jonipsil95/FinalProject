const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true, minlength: 1, maxlength: 50 },
  description: { type: String, required: true, minlength: 1, maxlength: 500 },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  languages: { type: [String], required: false } // המערך של השפות
});

const Project = mongoose.model('Project', projectSchema);

module.exports = Project;
