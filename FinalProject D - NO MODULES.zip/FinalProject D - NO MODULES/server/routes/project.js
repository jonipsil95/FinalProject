const express = require('express');
const Joi = require('joi');
const Project = require('../models/project');
const router = express.Router();
const auth = require('../middleware/auth'); // Middleware לאימות

// סכימת האימות החדשה ליצירת פרויקט
const projectSchema = Joi.object({
  title: Joi.string().min(3).max(50).required(),
  description: Joi.string().min(5).max(500).required(),
  languages: Joi.array().items(Joi.string()).optional()
});

// Route ליצירת פרויקט חדש (עם אימות)
router.post('/', auth, async (req, res) => {
  const { error } = projectSchema.validate(req.body); // אימות הגוף של הבקשה
  if (error) return res.status(400).send(error.details[0].message);

  const project = new Project({
    title: req.body.title,
    description: req.body.description,
    userId: req.user._id, // ה-UserId מתקבל מה-Token של המשתמש המחובר
    languages: req.body.languages || []
  });

  console.log('Project to be saved:', project);
  console.log('User ID:', req.user._id);

  try {
    await project.save();
    res.send(project);
  } catch (err) {
    console.error('Error creating project:', err);
    res.status(500).send('Error creating project');
  }
});

// Route לקבלת כל הפרויקטים
router.get('/', async (req, res) => {
  try {
    const projects = await Project.find().populate('userId', 'firstName lastName');
    res.send(projects);
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).send('Server error');
  }
});

// Route לקבלת פרויקט לפי ID
router.get('/:id', async (req, res) => {
  try {
    const project = await Project.findById(req.params.id).populate('userId', 'firstName lastName');
    if (!project) return res.status(404).send('Project not found');
    console.log('Project fetched by ID:', project);
    res.send(project);
  } catch (error) {
    console.error('Error fetching project by ID:', error);
    res.status(500).send('Server error');
  }
});

// Route למחיקת פרויקט לפי ID
router.delete('/:id', auth, async (req, res) => {
    try {
        const project = await Project.findById(req.params.id);
        if (!project) return res.status(404).send('Project not found');

        // בדיקה אם הפרויקט שייך למשתמש המחובר או שהוא אדמין
        const isAdmin = req.user._id === "66bacc4f6be4ec4b7586aa10"; // עדכון ה-ID של האדמין
        const isOwner = project.userId.toString() === req.user._id.toString();

        if (!isOwner && !isAdmin) {
            return res.status(403).send('User not authorized to delete this project');
        }

        await Project.deleteOne({ _id: req.params.id }); // שימוש ב-deleteOne למחיקת הפרויקט
        res.send({ message: 'Project removed successfully' });
    } catch (error) {
        console.error('Error removing project:', error);
        res.status(500).send('Server error');
    }
});

// Route לעדכון פרויקט לפי ID
router.put('/:id', auth, async (req, res) => {
  try {
      const { title } = req.body;
      const project = await Project.findById(req.params.id);
      if (!project) return res.status(404).send('Project not found');

      const isAdmin = req.user._id === "66bacc4f6be4ec4b7586aa10"; // עדכון ה-ID של האדמין
      const isOwner = project.userId.toString() === req.user._id.toString();

      if (!isOwner && !isAdmin) {
          return res.status(403).send('User not authorized to edit this project');
      }

      project.title = title;
      await project.save();

      // במקום רק הודעת הצלחה, נחזיר את הפרויקט המעודכן
      res.send(project);
  } catch (error) {
      console.error('Error updating project:', error);
      res.status(500).send('Server error');
  }
});

module.exports = router;
