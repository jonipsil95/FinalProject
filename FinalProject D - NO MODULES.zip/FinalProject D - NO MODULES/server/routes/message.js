const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Message = require('../models/message');

// Route for sending a message
router.post('/send', auth, async (req, res) => {
    const { recipientId, content } = req.body;
    const senderId = req.user._id;

    const message = new Message({
        sender: senderId,
        recipient: recipientId,
        content
    });

    try {
        await message.save();
        res.status(200).json({ message: 'Message sent successfully!' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to send message' });
    }
});

// Route for getting incoming messages
router.get('/inbox', auth, async (req, res) => {
    try {
        const messages = await Message.find({ recipient: req.user._id }).populate('sender', 'firstName lastName');
        res.status(200).json(messages);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch messages' });
    }
});

// Route for deleting a message
router.delete('/delete/:id', auth, async (req, res) => {
    try {
        const message = await Message.findById(req.params.id);
        if (!message) {
            return res.status(404).json({ error: 'Message not found' });
        }

        if (message.recipient.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'Unauthorized to delete this message' });
        }

        await message.remove();
        res.status(200).json({ message: 'Message deleted successfully!' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete message' });
    }
});

module.exports = router;
