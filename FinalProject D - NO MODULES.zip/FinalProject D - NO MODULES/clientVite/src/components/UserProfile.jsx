import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './UserProfile.css';

const UserProfile = () => {
  const { userId } = useParams();
  const [user, setUser] = useState(null);
  const [programmingLanguages, setProgrammingLanguages] = useState([]);
  const [error, setError] = useState(null);

  const currentUser = JSON.parse(localStorage.getItem('user')); // קבלת המשתמש הנוכחי מה-localStorage

  useEffect(() => {
    const fetchUser = async () => {
      try {
        if (!currentUser) {
          throw new Error('User not found in local storage');
        }

        const response = await fetch(`http://localhost:5001/api/users/${userId}`, {
          headers: {
            'Authorization': `Bearer ${currentUser.token}`, // הוספת ה-token בבקשה
          },
        });

        if (!response.ok) {
          throw new Error('User not found');
        }

        const data = await response.json();
        setUser(data);
        setProgrammingLanguages(data.languages || []); 
      } catch (error) {
        setError(error.message);
      }
    };

    fetchUser();
  }, [userId, currentUser]);

  if (error) {
    return <div>Error loading user profile: {error}</div>;
  }

  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="user-profile-container">
      <h1>{user.firstName} {user.lastName}</h1>
      <h2>Users Skill Languages</h2>
      <ul>
        {programmingLanguages.length > 0 ? (
          programmingLanguages.map((lang, index) => (
            <li key={index}>{lang}</li>
          ))
        ) : (
          <li>No programming languages selected</li>
        )}
      </ul>
      <h2>Projects</h2>
      <ul>
        {user.projects && user.projects.length > 0 ? (
          user.projects.map((project) => (
            <li key={project._id}>{project.name}</li>
          ))
        ) : (
          <li>No projects available</li>
        )}
      </ul>
      <h2>Friends</h2>
      <ul>
        {user.friends && user.friends.length > 0 ? (
          user.friends.map((friend) => (
            <li key={friend._id}>{friend.firstName} {friend.lastName}</li>
          ))
        ) : (
          <li>No friends available</li>
        )}
      </ul>
      <p className="bio">{user.bio}</p>
    </div>
  );
};

export default UserProfile;
