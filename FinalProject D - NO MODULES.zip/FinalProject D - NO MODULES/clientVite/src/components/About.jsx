
const About = () => {
  return (
    <div className="about-container">
      <h1>About Developarty</h1>
      <p>
        Welcome to Developarty, the ultimate platform for developers looking to share, collaborate, and grow their projects. Our platform offers an intuitive and user-friendly interface designed to meet the needs of developers at all levels. Whether you&apos;re a seasoned professional or just starting your journey, Developarty provides the tools and resources you need to succeed.
      </p>
      <p>
        Our platform allows you to showcase your work, connect with fellow developers, and receive valuable feedback from the community. With a wide range of features, including project management, collaboration tools, and a vibrant community, Developarty is the perfect place to build and expand your network.
      </p>
      <p>
        At Developarty, we believe that great things happen when developers come together. That&apos;s why we&apos;re committed to fostering a supportive and inclusive environment where everyone can thrive. Join us today and be part of a community that&apos;s passionate about coding, innovation, and making a difference in the world.
      </p>
    </div>
  );
};

export default About;
