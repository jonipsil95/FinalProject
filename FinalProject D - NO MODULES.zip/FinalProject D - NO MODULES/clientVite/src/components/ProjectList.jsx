import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaHeart, FaRegHeart } from 'react-icons/fa';
import './ProjectList.css';

const ProjectList = () => {
  const [projects, setProjects] = useState([]);
  const [user, setUser] = useState(null);
  const [favorites, setFavorites] = useState(new Set());

  const updateFavoritesInLocalStorage = (favorites) => {
    localStorage.setItem('favorites', JSON.stringify(Array.from(favorites)));
  };

  const updateProjectsInLocalStorage = (projects) => {
    const projectIds = projects.map(project => project._id);
    localStorage.setItem('projectIds', JSON.stringify(projectIds));
  };

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
    }

    const fetchFavorites = async () => {
      try {
        const localFavorites = JSON.parse(localStorage.getItem('favorites')) || [];
        setFavorites(new Set(localFavorites));

        const response = await fetch('http://localhost:5001/api/projects', {
          headers: storedUser ? { 'Authorization': `Bearer ${storedUser.token}` } : {},
        });
        if (!response.ok) {
          throw new Error('Error fetching projects');
        }
        const data = await response.json();
        setProjects(data);
        updateProjectsInLocalStorage(data); // עדכון ב-localStorage
      } catch (error) {
        console.error('%cError fetching projects:', 'color: red; font-weight: bold;', error);
      }
    };

    fetchFavorites();
  }, []);

  const handleRemoveProject = async (projectId) => {
    try {
      if (user) {
        const response = await fetch(`http://localhost:5001/api/projects/${projectId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${user.token}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to delete project');
        }
      }

      setProjects(projects.filter(project => project._id !== projectId));

      // עדכון המועדפים ב-localStorage
      const updatedFavorites = new Set(favorites);
      updatedFavorites.delete(projectId);
      updateFavoritesInLocalStorage(updatedFavorites);
      setFavorites(updatedFavorites);
    } catch (error) {
      console.error('%cError deleting project:', 'color: red; font-weight: bold;', error);
    }
  };

  const handleToggleFavorite = (projectId) => {
    const updatedFavorites = new Set(favorites);
    if (updatedFavorites.has(projectId)) {
      updatedFavorites.delete(projectId);
    } else {
      updatedFavorites.add(projectId);
    }

    setFavorites(updatedFavorites);
    updateFavoritesInLocalStorage(updatedFavorites);
  };

  const handleEditProject = (projectId) => {
    const newTitle = prompt('Enter new project title:');
    if (newTitle) {
      fetch(`http://localhost:5001/api/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.token}`,
        },
        body: JSON.stringify({ title: newTitle }),
      })
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to edit project');
          }
          return response.json();
        })
        .then(updatedProject => {
          setProjects(projects.map(project => 
            project._id === projectId ? { ...project, title: updatedProject.title } : project
          ));
        })
        .catch(error => {
          console.error('%cError editing project:', 'color: red; font-weight: bold;', error);
        });
    }
  };

  return (
    <div className="project-list">
      <h2>Projects</h2>
      {!user && (
        <p>You need to log in to view the projects</p>
      )}
      {user && projects.length > 0 ? (
        projects.map(project => {
          
          return (
            <div key={project._id} className="project-item">
              <h3>{project.title}</h3>
              <p>Languages: {project.languages.join(', ')}</p>
              <p>Posted by: {project.userName}</p>
              <Link to={`/projects/${project._id}`}>
                <button>Watch Project</button>
              </Link>
              {user && (project.userId && (project.userId._id.toString() === user._id.toString() || user.role === 'admin')) && (
                <>
                  <button onClick={() => handleRemoveProject(project._id)}>Remove Project</button>
                  <button onClick={() => handleEditProject(project._id)}>Edit Project</button>
                </>
              )}
              <button 
                className="favorite-button"
                onClick={() => handleToggleFavorite(project._id)}
              >
                {favorites.has(project._id) ? <FaHeart color="red" /> : <FaRegHeart />}
              </button>
            </div>
          );
        })
      ) : (
        <p>No projects available.</p>
      )}
    </div>
  );
};

export default ProjectList;
