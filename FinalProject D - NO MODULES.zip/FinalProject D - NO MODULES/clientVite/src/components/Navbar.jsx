import PropTypes from 'prop-types'; 
import { Link } from 'react-router-dom';
import { FaHome, FaSun } from 'react-icons/fa'; 
import './Navbar.css';

const Navbar = ({ user, setUser }) => {

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <Link className="navbar-brand" to="/">Developarty - Social World</Link> 
      <div className="collapse navbar-collapse">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/">
              <FaHome style={{ marginRight: '5px' }} />
            </Link>
          </li>
          <span className="nav-separator">|</span>
          <li className="nav-item">
            <Link className="nav-link" to="/projects">Projects</Link>
          </li>
          <span className="nav-separator">|</span>
          <li className="nav-item">
            <Link className="nav-link" to="/users">Users</Link>
          </li>
          <span className="nav-separator">|</span>
          <li className="nav-item">
            <Link className="nav-link" to="/about">About</Link>
          </li>
          <span className="nav-separator">|</span>
          {user && (
            <>
              <li className="nav-item">
                <Link className="nav-link" to="/favorite-projects">Favs</Link>
              </li>
              <span className="nav-separator">|</span>
            </>
          )}
          {!user ? (
            <>
              <li className="nav-item">
                <Link className="nav-link" to="/register">Register</Link>
              </li>
              <span className="nav-separator">|</span>
              <li className="nav-item">
                <Link className="nav-link" to="/login">Login</Link>
              </li>
              <span className="nav-separator">|</span>
              {/* הוספת אייקון השמש כאן */}
              <li className="nav-item">
                <FaSun className="sun-icon" />
              </li>
            </>
          ) : (
            <>
              <li className="nav-item">
                <span className="nav-link">Welcome, {user.firstName}!</span>
              </li>
              <span className="nav-separator">|</span>
              <li className="nav-item">
                <Link className="nav-link" to="/myprofile">My Profile</Link>
              </li>
              <span className="nav-separator">|</span>
              <li className="nav-item">
                <Link className="nav-link" to="/inbox">Inbox</Link>
              </li>
              <span className="nav-separator">|</span>
              <li className="nav-item">
                <button className="nav-linkLogout" onClick={handleLogout}>Logout</button>
              </li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

Navbar.propTypes = {
  user: PropTypes.shape({
    firstName: PropTypes.string,
  }),
  setUser: PropTypes.func.isRequired,
};

export default Navbar;
