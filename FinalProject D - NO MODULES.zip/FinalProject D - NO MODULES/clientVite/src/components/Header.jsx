import './Header.css'; 
import logo from './DevelopaLogo.png';
import GeneralText from './GeneralText';  
import { FaHtml5, FaCss3Alt, FaJs, FaReact, FaNodeJs, FaPython, FaJava, FaPhp, FaDatabase } from 'react-icons/fa';  // ייבוא האייקונים

function Header() {
  return (
    <>
      <div className="icons-bar">
        <FaHtml5 size={30} className="icon" />
        <span className="separator">|</span>
        <FaCss3Alt size={30} className="icon" />
        <span className="separator">|</span>
        <FaJs size={30} className="icon" />
        <span className="separator">|</span>
        <FaReact size={30} className="icon" />
        <span className="separator">|</span>
        <FaNodeJs size={30} className="icon" />
        <span className="separator">|</span>
        <FaPython size={30} className="icon" />
        <span className="separator">|</span>
        <FaJava size={30} className="icon" />
        <span className="separator">|</span>
        <FaPhp size={30} className="icon" />
        <span className="separator">|</span>
        <FaDatabase size={30} className="icon" />
      </div>
      
      <header className="header">
        <div className="logo">
          <img src={logo} alt="Logo" />
        </div>
        <GeneralText />  
        <nav className="navigation">
          <ul>
            {/* כאן יהיו פריטי הניווט שלך */}
          </ul>
        </nav>
      </header>
    </>
  );
}

export default Header;
