import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import './ProjectDetial.css';

const ProjectDetail = () => {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {

   const fetchProject = async () => {
  const storedUser = JSON.parse(localStorage.getItem('user'));

  if (!storedUser) {
    setError('User not found in localStorage');
    return;
  }

  try {
    const response = await fetch(`http://localhost:5001/api/projects/${id}`, {
      headers: {
        'Authorization': `Bearer ${storedUser.token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Error fetching project');
    }

    const data = await response.json();
    setProject(data);
  } catch (error) {
    setError('There was an error fetching the project details!');
    console.error(error);
  }
};

    fetchProject();
  }, [id]);

  if (error) {
    return <p>{error}</p>;
  }

  if (!project) {
    return <p>Loading project details...</p>;
  }

  return (
    <div className="project-details-container">
      <h1>{project.title}</h1>
      <p className="project-description">{project.description}</p>
      <p className="project-languages"><strong>Languages:</strong> {project.languages.join(', ')}</p>
      <p className="project-user">
        <strong>Posted by:</strong> 
        {project.userId.firstName ? `${project.userId.firstName} ${project.userId.lastName}` : 'Unknown User'}
      </p>
    </div>
  );
};

export default ProjectDetail;
