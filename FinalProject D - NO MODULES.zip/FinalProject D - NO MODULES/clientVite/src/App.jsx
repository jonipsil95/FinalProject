import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import ProjectList from './components/ProjectList';
import UserList from './components/UserList';
import Register from './components/Register';
import Home from './components/Home';
import Login from './components/Login';
import Header from './components/Header';
import UserProfile from './components/UserProfile';
import MyProfile from './components/MyProfile';
import ProjectDetail from './components/ProjectDetail';
import Inbox from './components/Inbox';
import FavoriteProjects from './components/FavoriteProjects';
import TermsOfService from './components/TermsOfService';
import ContactUs from './components/ContactUs';
import About from './components/About'; 
import Footer from './components/Footer'; 
import './App.css';

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
    }
  }, []);

  return (
    <Router>
      <Navbar user={user} setUser={setUser} />
      <Header />
      <div className="container mt-5">
        <Routes>
  <Route path="/" element={<Home />} /> 
  <Route path="/home" element={<Home />} />
  <Route path="/projects" element={<ProjectList />} />
  <Route path="/projects/:id" element={<ProjectDetail />} />
  <Route path="/users" element={<UserList />} />
  <Route path="/register" element={<Register />} />
  <Route path="/login" element={<Login setUser={setUser} />} />
  <Route path="/profile/:userId" element={<UserProfile />} />
  <Route path="/terms" element={<TermsOfService />} />
  <Route path="/contact" element={<ContactUs />} />
  <Route path="/about" element={<About />} />
  {user && (
    <>
      <Route path="/myprofile" element={<MyProfile />} />
      <Route path="/inbox" element={<Inbox />} />
      <Route path="/favorite-projects" element={<FavoriteProjects />} />
    </>
  )}
</Routes>
      </div>
      <Footer /> 
    </Router>
  );
}

export default App;
