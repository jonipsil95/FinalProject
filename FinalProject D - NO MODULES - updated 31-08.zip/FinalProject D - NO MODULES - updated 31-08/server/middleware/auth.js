const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
    const token = req.header('Authorization') || req.header('authorization');

    if (!token) return res.status(401).send('Access denied. No token provided.');

    try {
        const decoded = jwt.verify(token.replace('Bearer ', ''), 'jwtPrivateKey');
        req.user = decoded;

        // בדיקת user ID עבור הרשאות אדמין
        const adminId = "66b90d5b97f9430876609416";
        if (req.user._id === adminId) {
            // אם המשתמש הוא אדמין, מאפשרים לו לעבור ללא אימות נוסף
            return next();
        }

        next();
    } catch (ex) {
        res.status(400).send('Invalid token.');
    }
};

module.exports = auth;
