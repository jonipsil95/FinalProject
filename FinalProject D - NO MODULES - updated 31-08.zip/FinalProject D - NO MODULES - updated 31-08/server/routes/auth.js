const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Route for user login
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    let user = await User.findOne({ email });
    if (!user) return res.status(400).send('Invalid email or password.');

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).send('Invalid email or password.');

    const token = jwt.sign({ _id: user._id, role: user.role }, 'jwtPrivateKey'); // הוספת role ל-token

    // מחזירים את ה-id, השם הפרטי, ה-role וה-token של המשתמש
    res.send({ _id: user._id, firstName: user.firstName, role: user.role, token });
});

// Route for user registration
router.post('/register', async (req, res) => {
    const { firstName, lastName, userName, email, password } = req.body;

    let user = await User.findOne({ email });
    if (user) return res.status(400).send('User already registered.');

    user = new User({
        firstName,
        lastName,
        userName,
        email,
        password,
        role: 'user' // ברירת מחדל ל-role בעת רישום משתמש חדש
    });

    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);

    await user.save();

    // מחזירים את ה-id, השם הפרטי, ה-role וה-token של המשתמש החדש
    res.send({ _id: user._id, firstName: user.firstName, role: user.role, token: jwt.sign({ _id: user._id, role: user.role }, 'jwtPrivateKey') });
});

module.exports = router;
