const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const auth = require('../middleware/auth'); // הוספת אימות

// ראוט להחזרת כל המשתמשים
router.get('/', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (err) {
        console.error('Error fetching users:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

// ראוט להחזרת פרטי משתמש לפי userId
router.get('/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;

        console.log('Received ID:', userId);

        if (!/^[a-fA-F0-9]{24}$/.test(userId)) {
            return res.status(400).json({ message: 'Invalid ID length' });
        }

        const user = await User.findById(userId)
            .populate('projects')
            .populate('friends');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(user);
    } catch (error) {
        console.error('Error fetching user:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// ראוט לרישום משתמש
router.post('/register', async (req, res) => {
    const { firstName, lastName, email, password } = req.body;

    // ולידציה לסיסמה
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
        return res.status(400).send('Password must be at least 8 characters long, include uppercase and lowercase letters, a number, and a special character.');
    }

    let user = await User.findOne({ email });
    if (user) return res.status(400).send('User already registered.');

    user = new User({
        firstName,
        lastName,
        email,
        password
    });

    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);

    await user.save();
    res.send({ _id: user._id, firstName: user.firstName, token: jwt.sign({ _id: user._id }, 'jwtPrivateKey') });
});

// ראוט להתחברות משתמש
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    let user = await User.findOne({ email });
    if (!user) return res.status(400).send('Invalid email or password.');

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).send('Invalid email or password.');

    const token = jwt.sign({ _id: user._id }, 'jwtPrivateKey');

    res.send({ _id: user._id, firstName: user.firstName, token });
});

// ראוט להוספת חבר
router.post('/addFriend/:id', async (req, res) => {
    try {
        const { friendId } = req.body;
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });

        if (user.friends.includes(friendId)) {
            return res.status(400).json({ error: 'Friend already added' });
        }

        user.friends.push(friendId);
        await user.save();

        res.json({ message: 'Friend added successfully' });
    } catch (err) {
        console.error('Error adding friend:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

// ראוט להחזרת חברים לפי userId
router.get('/:userId/friends', async (req, res) => {
    try {
        const userId = req.params.userId;
        const user = await User.findById(userId).populate('friends');

        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(user.friends);
    } catch (err) {
        console.error('Error fetching friends:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

// ראוט להסרת חבר
router.post('/removeFriend/:id', async (req, res) => {
    try {
        const { friendId } = req.body;
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ error: 'User not found' });

        user.friends = user.friends.filter(id => id.toString() !== friendId);
        await user.save();

        res.json({ message: 'Friend removed successfully' });
    } catch (err) {
        console.error('Error removing friend:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

// ראוט להסרת משתמשים ללא שם פרטי ושם משפחה
router.delete('/remove-empty-users', async (req, res) => {
    try {
        const result = await User.deleteMany({
            $or: [
                { firstName: { $exists: false } },
                { lastName: { $exists: false } },
                { firstName: '' },
                { lastName: '' }
            ]
        });

        res.json({ message: 'Users removed successfully', result });
    } catch (err) {
        console.error('Error removing users:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

// ראוט לעדכון השפות של המשתמש
router.put('/:userId/languages', async (req, res) => {
    try {
        const { userId } = req.params;
        const { languages } = req.body;
        
        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { languages },
            { new: true }
        );
        
        if (!updatedUser) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(updatedUser);
    } catch (error) {
        console.error('Error updating user languages:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
});

// ראוט לעדכון המועדפים של המשתמש
router.post('/:userId/favorites', async (req, res) => {
    try {
        const { userId } = req.params; // קבל את ה-`userId` מ-`params`
        const { projectId } = req.body;

        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        if (user.favorites.includes(projectId)) {
            return res.status(400).json({ error: 'Project already in favorites' });
        }

        user.favorites.push(projectId);
        await user.save();

        res.json({ message: 'Favorites updated successfully' });
    } catch (err) {
        console.error('Error updating favorites:', err);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
