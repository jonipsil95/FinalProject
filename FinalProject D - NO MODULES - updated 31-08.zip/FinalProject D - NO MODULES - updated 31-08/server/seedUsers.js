const mongoose = require('mongoose');
const User = require('./models/user');

mongoose.connect('mongodb://localhost:27017/project_final', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

async function seedUsers() {
  const users = [
    { name: 'User One', email: 'user1@example.com', password: 'password1' },
    { name: 'User Two', email: 'user2@example.com', password: 'password2' },
    { name: 'User Three', email: 'user3@example.com', password: 'password3' },
    // תוסיף עוד משתמשים כאן
  ];

  for (let user of users) {
    const newUser = new User(user);
    await newUser.save();
  }

  console.log('Users inserted');
  mongoose.disconnect();
}

seedUsers();
