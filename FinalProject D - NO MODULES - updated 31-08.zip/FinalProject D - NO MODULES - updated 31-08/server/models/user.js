const mongoose = require('mongoose');
const Project = require('./project');

const userSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    projects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }],
    friends: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    languages: [{ type: String }], // שדה לאחסון השפות שהמשתמש למד
    favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }], // שדה לאחסון פרויקטים מועדפים
    role: { type: String, default: 'user' } // שדה לתפקיד המשתמש, ברירת המחדל היא "user"
});

module.exports = mongoose.model('User', userSchema);
