require('dotenv').config();

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const userRoutes = require('./routes/user');
const projectRoutes = require('./routes/project');
const authRoutes = require('./routes/auth');
const auth = require('./middleware/auth');

const app = express();
const port = process.env.PORT || 5001;
const mongoURI = process.env.MONGO_URI;

const corsOptions = {
  origin: '*',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  allowedHeaders: 'Content-Type,Authorization'
};

app.use(cors(corsOptions));
app.use(express.json());

// מסלולים מוגנים באמצעות auth
app.use('/api/users', auth, userRoutes);
app.use('/api/projects', auth, projectRoutes);
app.use('/api/auth', authRoutes);

mongoose.connect(mongoURI)
  .then(() => console.log('Connecting to MongoDB with URI:', mongoURI))
  .catch(err => console.error('Could not connect to MongoDB', err));

app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});
