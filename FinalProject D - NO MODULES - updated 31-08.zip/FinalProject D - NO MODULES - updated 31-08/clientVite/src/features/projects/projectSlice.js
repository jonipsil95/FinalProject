// src/features/projects/projectSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const fetchProjects = createAsyncThunk('projects/fetchProjects', async (_, { getState }) => {
  const state = getState();
  const token = state.user.currentUser?.token;

  const response = await fetch('http://localhost:5001/api/projects', {
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error('Failed to fetch projects');
  }
  return await response.json();
});

const initialState = {
  projects: [],
};

const projectSlice = createSlice({
  name: 'projects',
  initialState,
  reducers: {
    setProjects: (state, action) => {
      state.projects = action.payload;
    },
    updateProject: (state, action) => {
      const index = state.projects.findIndex(project => project._id === action.payload._id);
      if (index !== -1) {
        state.projects[index] = action.payload;
      }
    },
    removeProject: (state, action) => {
      state.projects = state.projects.filter(project => project._id !== action.payload);
    },
    addProject: (state, action) => {
      state.projects.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProjects.fulfilled, (state, action) => {
        state.projects = action.payload;
      })
      .addCase(fetchProjects.rejected, (state, action) => {
        console.error('Failed to fetch projects:', action.error.message);
      });
  },
});

export const { setProjects, updateProject, removeProject, addProject } = projectSlice.actions;

export default projectSlice.reducer;
