// src/features/user/userSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  currentUser: null,
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.currentUser = { ...action.payload, favorites: action.payload.favorites || [] };
    },
    clearUser: (state) => {
      state.currentUser = null;
    },
    addFavorite: (state, action) => {
      if (state.currentUser) {
        state.currentUser.favorites.push(action.payload);
        localStorage.setItem('user', JSON.stringify(state.currentUser));
      }
    },
    removeFavorite: (state, action) => {
      if (state.currentUser) {
        state.currentUser.favorites = state.currentUser.favorites.filter(id => id !== action.payload);
        localStorage.setItem('user', JSON.stringify(state.currentUser));
      }
    },
  },
});

export const { setUser, clearUser, addFavorite, removeFavorite } = userSlice.actions;

export default userSlice.reducer;
