import { useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { FaHeart, FaRegHeart, FaSun } from 'react-icons/fa';
import './FavoriteProjects.css';
import { addFavorite, removeFavorite } from '../features/user/userSlice';

const FavoriteProjects = () => {
  const user = useSelector((state) => state.user.currentUser);
  const dispatch = useDispatch();

  const projects = useMemo(() => {
    if (!user || !user.favorites) return [];
    return user.favorites.map(id => ({
      _id: id,
      title: `Project ${id}`,
      languages: ['JavaScript', 'Node.js'],
      userName: 'Admin',
    }));
  }, [user]);

  const handleToggleFavorite = (projectId) => {
    if (user.favorites.includes(projectId)) {
      dispatch(removeFavorite(projectId));
    } else {
      dispatch(addFavorite(projectId));
    }
  };

  return (
    <div className="favorite-projects">
      <h2>Favorite Projects</h2>
      {projects.length > 0 ? (
        projects.map(project => (
          <div key={project._id} className="project-item">
            <h3>{project.title}</h3>
            <p><FaSun /> ID: {project._id}</p> {/* הוספתי את אייקון השמש מעל ה-ID */}
            <p>Languages: {project.languages.join(', ')}</p>
            <p>Posted by: {project.userName}</p>
            <Link to={`/projects/${project._id}`}>
              <button>Watch Project</button>
            </Link>
            <button 
              className="favorite-button"
              onClick={() => handleToggleFavorite(project._id)}
            >
              {user.favorites.includes(project._id) ? <FaHeart color="red" /> : <FaRegHeart />}
            </button>
          </div>
        ))
      ) : (
        <p>You have no favorite projects yet.</p>
      )}
    </div>
  );
};

export default FavoriteProjects;
