
import './Footer.css'; 
import logo from './DevelopaLogo.png';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-logo">
        <img src={logo} alt="Developarty Logo" style={{ width: '100px', height: 'auto' }} /> 

        </div>
        <div className="footer-links">
          <a href="/terms">Terms of Service</a> | 
          <a href="/contact">Contact Us</a>
        </div>
        <div className="footer-copyright">
          © {new Date().getFullYear()} Developarty. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
