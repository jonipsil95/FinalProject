import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './UserList.css'; 
import SendMessage from './SendMessage';

function UserList() {
  const [users, setUsers] = useState([]);
  const [message, setMessage] = useState('');
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [showSendMessage, setShowSendMessage] = useState(false); // מצב הצגת תיבת ההודעה
  const navigate = useNavigate();
  const currentUser = JSON.parse(localStorage.getItem('user'));

  const fetchUsers = useCallback(async () => {
    try {
      if (!currentUser) {
        setMessage('Please login to view users.');
        return;
      }

      const response = await fetch('http://localhost:5001/api/users', {
        headers: {
          'Authorization': `Bearer ${currentUser.token}`,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error fetching users');
      }

      const data = await response.json();
      const validUsers = data.filter(user => user && user._id);
      setUsers(validUsers);
    } catch (error) {
      console.error('Error fetching the users:', error);
      setMessage(error.message || 'Error fetching users');
    }
  }, [currentUser]);

  const handleAddFriend = async (friendId) => {
    try {
      if (!currentUser) {
        throw new Error('User not found in local storage');
      }

      const response = await fetch(`http://localhost:5001/api/users/addFriend/${currentUser._id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`,
        },
        body: JSON.stringify({ friendId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Friend already in your list');
      }

      setMessage('Friend added successfully!');
      setTimeout(() => {
        setMessage('');
      }, 3000);

      fetchUsers(); // עדכון רשימת המשתמשים לאחר הוספת חבר
    } catch (error) {
      console.error('Error adding friend:', error);
      setMessage(error.message || 'Friend already in your list');
      setTimeout(() => {
        setMessage('');
      }, 3000);
    }
  };

  const handleRemoveFriend = async (friendId) => {
    try {
      if (!currentUser) {
        throw new Error('User not found in local storage');
      }

      const response = await fetch(`http://localhost:5001/api/users/removeFriend/${currentUser._id}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentUser.token}`,
        },
        body: JSON.stringify({ friendId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Error removing friend');
      }

      setMessage('Friend removed successfully!');
      setTimeout(() => {
        setMessage('');
      }, 3000);

      fetchUsers(); // עדכון רשימת המשתמשים לאחר הסרת חבר
    } catch (error) {
      console.error('Error removing friend:', error);
      setMessage(error.message || 'Error removing friend');
      setTimeout(() => {
        setMessage('');
      }, 3000);
    }
  };

  const handleProfileClick = (userId) => {
    navigate(`/profile/${userId}`);
  };

  const handleSendMessageClick = (userId) => {
    setSelectedUserId(userId);
    setShowSendMessage(true); // הצג את תיבת ההודעה
  };

  const handleCloseSendMessage = () => {
    setShowSendMessage(false);
    setSelectedUserId(null); // נקה את המשתמש שנבחר
  };

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  return (
    <div className="user-list-container">
      <h1>Users List</h1>
      {message && <p>{message}</p>}
      {currentUser ? (
        <ul>
          {users.map(user => (
            user.firstName && user.lastName && (
              <li key={user._id}>
                {user.firstName} {user.lastName}
                {currentUser && user._id !== currentUser._id && (
                  <>
                    <button className="small-button" onClick={() => handleAddFriend(user._id)}>Add Friend</button>
                    <button className="small-button" onClick={() => handleRemoveFriend(user._id)}>Remove Friend</button>
                    <button className="small-button" onClick={() => handleSendMessageClick(user._id)}>Send Message</button>
                  </>
                )}
                <button className="small-button" onClick={() => handleProfileClick(user._id)}>Watch Profile</button>
              </li>
            )
          ))}
        </ul>
      ) : (
        <p>Please login to view the user list.</p>
      )}
      <div className={`send-message-container ${showSendMessage ? 'active' : ''}`}>
        {showSendMessage && selectedUserId && (
          <SendMessage recipientId={selectedUserId} onClose={handleCloseSendMessage} />
        )}
      </div>
    </div>
  );
}

export default UserList;
