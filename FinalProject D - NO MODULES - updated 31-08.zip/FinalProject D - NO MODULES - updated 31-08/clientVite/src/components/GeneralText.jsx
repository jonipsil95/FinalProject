
import './GeneralText.css';

function GeneralText() {
  return (
    <div className="general-text">
      <p>Welcome to Developarty - the ultimate platform for developers.</p>
      <p>Connect with fellow developers, share your projects, and build your network.</p>
    </div>
  );
}


export default GeneralText;
