import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa'; // ייבוא האייקון של בנאדם
import './MyProfile.css';

const MyProfile = () => {
    const [projectTitle, setProjectTitle] = useState('');
    const [projectDescription, setProjectDescription] = useState('');
    const [uploadStatus, setUploadStatus] = useState('');
    const [selectedLanguages, setSelectedLanguages] = useState([]);
    const [friends, setFriends] = useState([]);

    const programmingLanguages = [
        'JavaScript', 
        'Python', 
        'Java', 
        'C#', 
        'C++', 
        'Ruby', 
        'PHP', 
        'TypeScript',
        'React',
        'HTML',
        'CSS',
        'Node.js'
    ];

    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem('user'));
        if (storedUser && storedUser.programmingLanguages) {
            setSelectedLanguages(storedUser.programmingLanguages);
        }

        if (storedUser && storedUser.token) {
            fetch(`http://localhost:5001/api/users/${storedUser._id}/friends`, {
                headers: {
                    'Authorization': `Bearer ${storedUser.token}`
                }
            })
            .then(response => response.json())
            .then(data => setFriends(data))
            .catch(error => console.error('Error fetching friends:', error));
        }
    }, []);

    const handleLanguageChange = (event) => {
        const options = event.target.options;
        const selected = [];
        for (let i = 0; i < options.length; i++) {
            if (options[i].selected) {
                selected.push(options[i].value);
            }
        }
        setSelectedLanguages(selected);
    };

   const handleSaveLanguages = (event) => {
    event.preventDefault();

    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
        storedUser.programmingLanguages = selectedLanguages;
        localStorage.setItem('user', JSON.stringify(storedUser));
       
    }

    console.log('Selected languages:', selectedLanguages);
    setUploadStatus('Your programming languages have been saved successfully!');
    setTimeout(() => setUploadStatus(null), 3000);
};

    const handleUploadProject = async (event) => {
        event.preventDefault();

        const storedUser = JSON.parse(localStorage.getItem('user'));
        const token = storedUser ? storedUser.token : null;

        const projectData = {
            title: projectTitle,
            description: projectDescription,
            languages: selectedLanguages 
        };

        try {
            const response = await fetch('http://localhost:5001/api/projects', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify(projectData)
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const result = await response.json();
            console.log('Project uploaded successfully:', result);
            setUploadStatus('Project uploaded successfully!');
        } catch (error) {
            console.error('Error uploading project:', error);
            setUploadStatus('Error uploading project');
        }
    };

    return (
        <div>
            <FaUserCircle size={100} style={{ display: 'block', margin: '0 auto' }} /> {/* הוספת האייקון של הבנאדם */}
            <h2>My Profile</h2>
            <form onSubmit={handleSaveLanguages}>
                <label>Select your programming languages:</label>
                <select multiple={true} value={selectedLanguages} onChange={handleLanguageChange} className="languages-dropdown">
                    {programmingLanguages.map((lang) => (
                        <option key={lang} value={lang}>{lang}</option>
                    ))}
                </select>
                <button type="submit">Save</button>
            </form>

            <h2>Upload New Project</h2>
            <form onSubmit={handleUploadProject}>
                <label>
                    Project Title:
                    <input
                        type="text"
                        value={projectTitle}
                        onChange={(e) => setProjectTitle(e.target.value)}
                    />
                </label>
                <br />
                <label>
                    Description:
                    <textarea
                        value={projectDescription}
                        onChange={(e) => setProjectDescription(e.target.value)}
                    />
                </label>
                <br />
                <button type="submit">Upload Project</button>
                {uploadStatus && <p>{uploadStatus}</p>}
            </form>

            <h2>My Friends</h2>
            <ul className="friends-list">
                {friends.length > 0 ? (
                    friends.map((friend) => (
                        <li key={friend._id}>
                            <Link to={`/profile/${friend._id}`} className="friend-link">
                                {friend.firstName} {friend.lastName}
                            </Link>
                        </li>
                    ))
                ) : (
                    <p>You have no friends added yet.</p>
                )}
            </ul>
        </div>
    );
};

export default MyProfile;
