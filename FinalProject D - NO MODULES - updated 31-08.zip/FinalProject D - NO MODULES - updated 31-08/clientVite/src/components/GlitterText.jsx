
import PropTypes from 'prop-types';
import './Glitter.css'; // יש לכלול את ה-CSS בקובץ חיצוני

function GlitterText({ text }) {
  return <span className="glitter-effect">{text}</span>;
}

GlitterText.propTypes = {
  text: PropTypes.string.isRequired,
};

export default GlitterText;
