import Sparkle from 'react-sparkle';
import { FaYoutube, FaInstagram, FaTiktok, FaTwitter, FaLinkedin, FaFacebook } from 'react-icons/fa';
import logo from '../assets/develoPainting.png'; 
import './Home.css';

function Home() {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div className="home">
      <div className="text-container">
        <h1 className="welcome-text">
          ~ D E V E L O P A R T Y ! ~
          <Sparkle
            color="gold"
            count={30}
            fadeOutSpeed={20}
            flicker={false}
            overflowPx={10}
          />
        </h1>
      </div>

      <div className="social-icons">
        <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
          <FaYoutube color="#FF0000" size="40px" />
        </a>
        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">
          <FaInstagram color="#E4405F" size="40px" />
        </a>
        <a href="https://www.tiktok.com" target="_blank" rel="noopener noreferrer">
          <FaTiktok color="#000000" size="40px" />
        </a>
        <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
          <FaTwitter color="#1DA1F2" size="40px" />
        </a>
        <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
          <FaLinkedin color="#0077B5" size="40px" />
        </a>
        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
          <FaFacebook color="#1877F2" size="40px" />
        </a>
      </div>

      <img src={logo} alt="Logo" className="centered-logo" />
      <div className="text-container-bottom">
        <h1 className="welcome-text">
        </h1>
      </div>

      {user && (
        <h2>Welcome, {user.firstName} {user.lastName}!</h2>
      )}
    </div>
  );
}

export default Home;
