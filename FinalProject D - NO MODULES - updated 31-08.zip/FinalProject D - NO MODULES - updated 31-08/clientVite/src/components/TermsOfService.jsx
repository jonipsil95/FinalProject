const TermsOfService = () => {
  return (
    <div className="terms-of-service">
      <h2>Terms of Service</h2>
      <p>This is where you would include the text for your Terms of Service .
        Be aware that all rights saved to Jonathan Levy on this project ©.
      </p>
     
    </div>
  );
};

export default TermsOfService;
