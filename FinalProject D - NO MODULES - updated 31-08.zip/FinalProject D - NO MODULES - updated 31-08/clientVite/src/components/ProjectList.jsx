import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { FaHeart, FaRegHeart } from 'react-icons/fa';
import './ProjectList.css';
import { addFavorite, removeFavorite, setUser } from '../features/user/userSlice';
import { fetchProjects, updateProject } from '../features/projects/projectSlice'; // ייבוא הפונקציות מ-projectSlice

const ProjectList = () => {
  const projects = useSelector((state) => state.projects.projects); // נניח שהפרויקטים מאוחסנים ב-Redux
  const user = useSelector((state) => state.user.currentUser);
  const dispatch = useDispatch();

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      dispatch(setUser(storedUser));
    }

    // טעינת הפרויקטים מהשרת ל-Redux
    dispatch(fetchProjects());
  }, [dispatch]);

  const handleRemoveProject = async (projectId) => {
    try {
      if (user) {
        const response = await fetch(`http://localhost:5001/api/projects/${projectId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${user.token}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to delete project');
        }
      }

      // כאן נניח שיש לנו reducer ב-Redux שמטפל במחיקה
      // dispatch(removeProject(projectId));

    } catch (error) {
      console.error('%cError deleting project:', 'color: red; font-weight: bold;', error);
    }
  };

  const handleToggleFavorite = (projectId) => {
    if (user.favorites.includes(projectId)) {
      dispatch(removeFavorite(projectId));
    } else {
      dispatch(addFavorite(projectId));
    }
  };

  const handleEditProject = (projectId) => {
    const newTitle = prompt('Enter new project title:');
    if (newTitle) {
      fetch(`http://localhost:5001/api/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${user.token}`,
        },
        body: JSON.stringify({ title: newTitle }),
      })
        .then(response => {
          if (!response.ok) {
            throw new Error('Failed to edit project');
          }
          return response.json();
        })
        .then(updatedProject => {
          // עדכון הפרויקט ב-Redux
          dispatch(updateProject(updatedProject));
        })
        .catch(error => {
          console.error('%cError editing project:', 'color: red; font-weight: bold;', error);
        });
    }
  };

  return (
    <div className="project-list">
      <h2>Projects</h2>
      {!user && (
        <p>You need to log in to view the projects</p>
      )}
      {user && projects.length > 0 ? (
        projects.map(project => (
          <div key={project._id} className="project-item">
            <h3>{project.title}</h3>
            <p>Languages: {project.languages.join(', ')}</p>
            <p>Posted by: {project.userName}</p>
            <Link to={`/projects/${project._id}`}>
              <button>Watch Project</button>
            </Link>
            {user && (project.userId && (project.userId._id.toString() === user._id.toString() || user.role === 'admin')) && (
              <>
                <button onClick={() => handleRemoveProject(project._id)}>Remove Project</button>
                <button onClick={() => handleEditProject(project._id)}>Edit Project</button>
              </>
            )}
            <button 
              className="favorite-button"
              onClick={() => handleToggleFavorite(project._id)}
            >
              {user.favorites.includes(project._id) ? <FaHeart color="red" /> : <FaRegHeart />}
            </button>
          </div>
        ))
      ) : (
        <p>No projects available.</p>
      )}
    </div>
  );
};

export default ProjectList;
