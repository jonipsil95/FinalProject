import { useState, useEffect } from 'react';

function MyFriends() {
  const [friends, setFriends] = useState([]);
  const currentUser = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        const response = await fetch(`http://localhost:5001/api/users/${currentUser._id}/friends`, {
          headers: {
            'Authorization': `Bearer ${currentUser.token}`,
          }
        });
        const data = await response.json();
        setFriends(data);
      } catch (error) {
        console.error('Error fetching friends:', error);
      }
    };

    if (currentUser) {
      fetchFriends();
    } else {
      console.error('No user found in localStorage');
    }
  }, [currentUser]);

  return (
    <div>
      <h1>My Friends</h1>
      <ul>
        {friends.map(friend => (
          <li key={friend._id}>{friend.firstName} {friend.lastName}</li>
        ))}
      </ul>
    </div>
  );
}

export default MyFriends;
