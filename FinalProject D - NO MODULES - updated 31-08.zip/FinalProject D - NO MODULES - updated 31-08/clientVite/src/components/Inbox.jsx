import { useState, useEffect } from 'react';

function Inbox() {
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        const fetchMessages = async () => {
            try {
                const user = JSON.parse(localStorage.getItem('user'));
                const response = await fetch('http://localhost:5001/api/messages/inbox', {
                    headers: {
                        'Authorization': `Bearer ${user.token}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    setMessages(data);
                } else {
                    console.error('Failed to fetch messages', await response.text());
                }
            } catch (error) {
                console.error('Failed to fetch messages', error);
            }
        };

        fetchMessages();
    }, []);

    return (
        <div>
            <h2>Inbox</h2>
            <ul>
                {messages.map(message => (
                    <li key={message._id}>
                        From: {message.sender.firstName} {message.sender.lastName}<br />
                        {message.content}<br />
                        <button>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Inbox;
