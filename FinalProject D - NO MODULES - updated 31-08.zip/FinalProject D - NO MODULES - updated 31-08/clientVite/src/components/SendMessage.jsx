import { useState } from 'react';
import PropTypes from 'prop-types';

function SendMessage({ recipientId, onClose }) {
  const [message, setMessage] = useState('');
  const [sentMessages, setSentMessages] = useState([]);

  const handleSend = () => {
    if (!message.trim()) {
      alert('Please enter a message');
      return;
    }

    const newMessage = {
      recipientId,
      text: message,
      timestamp: new Date().toISOString(),
    };

    // Add the message to local state
    setSentMessages([...sentMessages, newMessage]);
    setMessage('');

    // Close the message box
    if (onClose) {
      onClose();
    }
  };

  return (
    <div className="send-message-container">
      <h2>Send Message</h2>
      <textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message here..."
      />
      <button onClick={handleSend}>Send</button>
      <button onClick={onClose}>Close</button>
      <div className="sent-messages">
        <h3>Sent Messages:</h3>
        <ul>
          {sentMessages.map((msg, index) => (
            <li key={index}>
              {msg.timestamp} - {msg.text}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// PropTypes
SendMessage.propTypes = {
  recipientId: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
};

export default SendMessage;
